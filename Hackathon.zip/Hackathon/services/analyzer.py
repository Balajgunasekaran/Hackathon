from services.knowledge_loader import load_knowledge_base


def analyze_log(log_content):

    kb = load_knowledge_base()

    best_match = None
    best_score = 0
    matched_patterns = []

    log_lower = log_content.lower()

    for rule in kb["rules"]:

        current_matches = []

        score = 0

        for pattern in rule["patterns"]:

            if pattern.lower() in log_lower:
                score += 1
                current_matches.append(pattern)

        if score > best_score:
            best_score = score
            best_match = rule
            matched_patterns = current_matches

    return {
        "rule": best_match,
        "matched_patterns": matched_patterns,
        "score": best_score
    }