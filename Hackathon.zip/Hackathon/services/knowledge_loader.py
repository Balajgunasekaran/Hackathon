import json

def load_knowledge_base():
    with open(
        "data/knowledge_base.json",
        "r",
        encoding="utf-8"
    ) as file:
        return json.load(file)