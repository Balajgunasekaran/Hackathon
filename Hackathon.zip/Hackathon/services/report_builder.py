def build_report(rule, matched_patterns):

    return {
        "classification": rule["scenario"],
        "priority": "P1" if rule["severity"] == "Critical" else "P2",
        "severity": rule["severity"],
        "confidence": rule["confidence"],
        "root_cause": rule["probableRootCause"],
        "recovery_action": rule["recoveryAction"],
        "restart_guidance": rule["restartGuidance"],
        "evidence": matched_patterns,

        # Mock hackathon data
        "jira_evidence": [
            "JIRA-2451 Similar database timeout incident",
            "JIRA-2678 Previous trade retrieval failure"
        ],

        "gerrit_evidence": [
            "Change-10987 Database connection pool changes",
            "Change-11012 Trade retrieval optimization"
        ],

        "code_evidence": [
            "TradeRepository.cs",
            "DatabaseConnectionManager.cs"
        ],

        "recommended_experts": [
            "Database Support Team",
            "Trade Services Team",
            "Infrastructure Support Team"
        ]
    }