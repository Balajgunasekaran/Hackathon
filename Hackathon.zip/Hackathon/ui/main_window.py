import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import filedialog

from services.analyzer import analyze_log


# ---------------------------------------------------------
# Color palette
# ---------------------------------------------------------

COLOR_BACKGROUND = "#F3F6FA"
COLOR_CARD = "#FFFFFF"
COLOR_PRIMARY = "#0067B8"
COLOR_PRIMARY_DARK = "#005A9E"
COLOR_TEXT = "#1F2937"
COLOR_MUTED = "#667085"
COLOR_BORDER = "#D0D5DD"
COLOR_DANGER = "#B42318"
COLOR_DANGER_BACKGROUND = "#FEE4E2"
COLOR_SUCCESS = "#067647"
COLOR_SUCCESS_BACKGROUND = "#DCFAE6"
COLOR_WARNING = "#B54708"
COLOR_WARNING_BACKGROUND = "#FEF0C7"


# ---------------------------------------------------------
# Expert recommendation mapping
# ---------------------------------------------------------

EXPERT_MAPPING = {
    "Trade Retrieval": [
        "Database Support Team",
        "Trade Services Team",
        "Infrastructure Support Team"
    ],
    "SFTP Delivery": [
        "Middleware Team",
        "Network Team",
        "SFTP Support Team"
    ],
    "Email Report Delivery": [
        "Messaging Team",
        "Application Support Team"
    ],
    "CSV Line Creation": [
        "Development Team",
        "Application Support Team"
    ],
    "Filter Initialization": [
        "Application Support Team",
        "Configuration Management Team"
    ]
}


# ---------------------------------------------------------
# Helper functions
# ---------------------------------------------------------

def set_text(widget, content):
    """
    Safely update a read-only Text widget.
    """

    widget.config(state="normal")
    widget.delete("1.0", tk.END)
    widget.insert(tk.END, content)
    widget.config(state="disabled")


def update_status(message, color=COLOR_MUTED):
    """
    Update the status message displayed at the bottom.
    """

    status_label.config(
        text=message,
        fg=color
    )


def clear_results():
    """
    Reset all investigation result controls.
    """

    classification_value.config(text="Not analyzed")
    priority_value.config(text="--")
    severity_value.config(text="--")
    confidence_value.config(text="--")

    set_text(
        overview_text,
        "Investigation results will appear here after analysis."
    )

    set_text(
        evidence_text,
        "Matched log evidence will appear here."
    )

    set_text(
        actions_text,
        "Investigation and recovery steps will appear here."
    )

    update_status("Ready for incident analysis.")


def clear_form():
    """
    Clear incident details, logs, and existing results.
    """

    incident_text.delete("1.0", tk.END)
    log_text.delete("1.0", tk.END)

    clear_results()

    update_status("Form cleared.")


def upload_log_file():
    """
    Allow the user to select a production log file.
    """

    file_path = filedialog.askopenfilename(
        title="Select Production Log",
        filetypes=[
            ("Log files", "*.log"),
            ("Text files", "*.txt"),
            ("All files", "*.*")
        ]
    )

    if not file_path:
        return

    try:
        with open(
            file_path,
            "r",
            encoding="utf-8",
            errors="replace"
        ) as log_file:
            content = log_file.read()

        log_text.delete("1.0", tk.END)
        log_text.insert(tk.END, content)

        selected_file_label.config(
            text=file_path,
            fg=COLOR_SUCCESS
        )

        update_status(
            "Production log loaded successfully.",
            COLOR_SUCCESS
        )

    except Exception as error:
        messagebox.showerror(
            "Log Upload Error",
            f"Unable to read the selected log file.\n\n{error}"
        )


def get_priority(severity):
    """
    Convert incident severity into operational priority.
    """

    priority_mapping = {
        "Critical": "P1",
        "High": "P2",
        "Medium": "P3",
        "Low": "P4"
    }

    return priority_mapping.get(severity, "P3")


def apply_severity_style(severity):
    """
    Apply a color style to the severity result.
    """

    if severity == "Critical":
        severity_value.config(
            fg=COLOR_DANGER,
            bg=COLOR_DANGER_BACKGROUND
        )

    elif severity == "High":
        severity_value.config(
            fg=COLOR_WARNING,
            bg=COLOR_WARNING_BACKGROUND
        )

    else:
        severity_value.config(
            fg=COLOR_SUCCESS,
            bg=COLOR_SUCCESS_BACKGROUND
        )


def analyze_incident():
    """
    Analyze the production log and display the investigation report.
    """

    application_name = app_combo.get().strip()
    environment_name = env_combo.get().strip()

    incident_details = incident_text.get(
        "1.0",
        tk.END
    ).strip()

    logs = log_text.get(
        "1.0",
        tk.END
    ).strip()

    if not application_name:
        messagebox.showwarning(
            "Missing Application",
            "Please select an application."
        )
        return

    if not environment_name:
        messagebox.showwarning(
            "Missing Environment",
            "Please select an environment."
        )
        return

    if not incident_details:
        messagebox.showwarning(
            "Missing Incident Details",
            "Please enter a brief incident description."
        )
        return

    if not logs:
        messagebox.showwarning(
            "Missing Production Log",
            "Please paste or upload a production log before analysis."
        )
        return

    try:
        analyze_button.config(
            text="Analyzing...",
            state="disabled"
        )

        progress_bar.start(10)

        update_status(
            "TraceFix AI is investigating the incident...",
            COLOR_PRIMARY
        )

        root.update_idletasks()

        result = analyze_log(logs)
        rule = result.get("rule")

        progress_bar.stop()

        analyze_button.config(
            text="Analyze Incident",
            state="normal"
        )

        if rule is None:
            clear_results()

            classification_value.config(
                text="No known pattern"
            )

            set_text(
                overview_text,
                "TraceFix AI could not find a matching incident pattern.\n\n"
                "Add additional exception messages, stack-trace details, "
                "or failure indicators and run the analysis again."
            )

            update_status(
                "No matching knowledge-base rule was found.",
                COLOR_WARNING
            )

            return

        severity = rule.get(
            "severity",
            "Unknown"
        )

        priority = get_priority(severity)

        classification = rule.get(
            "scenario",
            "Unknown"
        )

        confidence = rule.get(
            "confidence",
            0
        )

        stage = rule.get(
            "stage",
            "Unknown"
        )

        probable_root_cause = rule.get(
            "probableRootCause",
            "Root cause unavailable."
        )

        recovery_action = rule.get(
            "recoveryAction",
            "Recovery action unavailable."
        )

        restart_guidance = rule.get(
            "restartGuidance",
            "Restart guidance unavailable."
        )

        matched_patterns = result.get(
            "matched_patterns",
            []
        )

        suggested_actions = rule.get(
            "suggestedActions",
            []
        )

        impact_items = rule.get(
            "impact",
            []
        )

        experts = EXPERT_MAPPING.get(
            stage,
            ["Application Support Team"]
        )

        classification_value.config(
            text=classification
        )

        priority_value.config(
            text=priority
        )

        severity_value.config(
            text=severity
        )

        confidence_value.config(
            text=f"{confidence}%"
        )

        apply_severity_style(severity)

        overview_content = (
            f"APPLICATION\n"
            f"{application_name}\n\n"
            f"ENVIRONMENT\n"
            f"{environment_name}\n\n"
            f"FAILED STAGE\n"
            f"{stage}\n\n"
            f"INCIDENT DETAILS\n"
            f"{incident_details}\n\n"
            f"PROBABLE ROOT CAUSE\n"
            f"{probable_root_cause}\n\n"
            f"POTENTIAL RESOLUTION\n"
            f"{recovery_action}\n\n"
            f"RESTART GUIDANCE\n"
            f"{restart_guidance}"
        )

        if matched_patterns:
            evidence_lines = "\n".join(
                f"• {pattern}"
                for pattern in matched_patterns
            )
        else:
            evidence_lines = (
                "No exact knowledge-base patterns were recorded."
            )

        if impact_items:
            impact_lines = "\n".join(
                f"• {impact}"
                for impact in impact_items
            )
        else:
            impact_lines = "Impact information is unavailable."

        evidence_content = (
            f"MATCHED LOG EVIDENCE\n\n"
            f"{evidence_lines}\n\n"
            f"EXPECTED INCIDENT IMPACT\n\n"
            f"{impact_lines}"
        )

        if suggested_actions:
            action_lines = "\n".join(
                f"{number}. {action}"
                for number, action in enumerate(
                    suggested_actions,
                    start=1
                )
            )
        else:
            action_lines = (
                "1. Review the application logs.\n"
                "2. Review recent configuration changes.\n"
                "3. Contact application support."
            )

        expert_lines = "\n".join(
            f"• {expert}"
            for expert in experts
        )

        actions_content = (
            f"INVESTIGATION STEPS\n\n"
            f"{action_lines}\n\n"
            f"RECOMMENDED EXPERTS\n\n"
            f"{expert_lines}"
        )

        set_text(
            overview_text,
            overview_content
        )

        set_text(
            evidence_text,
            evidence_content
        )

        set_text(
            actions_text,
            actions_content
        )

        result_notebook.select(overview_tab)

        update_status(
            "Incident analysis completed successfully.",
            COLOR_SUCCESS
        )

    except Exception as error:
        progress_bar.stop()

        analyze_button.config(
            text="Analyze Incident",
            state="normal"
        )

        update_status(
            "Incident analysis failed.",
            COLOR_DANGER
        )

        messagebox.showerror(
            "Analysis Error",
            "TraceFix AI could not analyze the incident.\n\n"
            f"Error details:\n{error}"
        )


# ---------------------------------------------------------
# Main window
# ---------------------------------------------------------

root = tk.Tk()

root.title("TraceFix AI")
root.geometry("1280x820")
root.minsize(1000, 680)
root.configure(bg=COLOR_BACKGROUND)

try:
    root.state("zoomed")
except tk.TclError:
    pass


# ---------------------------------------------------------
# ttk styles
# ---------------------------------------------------------

style = ttk.Style()

try:
    style.theme_use("clam")
except tk.TclError:
    pass

style.configure(
    "TCombobox",
    padding=7
)

style.configure(
    "TNotebook",
    background=COLOR_CARD,
    borderwidth=0
)

style.configure(
    "TNotebook.Tab",
    padding=(18, 9),
    font=("Segoe UI", 10, "bold")
)

style.map(
    "TNotebook.Tab",
    background=[
        ("selected", COLOR_PRIMARY)
    ],
    foreground=[
        ("selected", "white")
    ]
)

# ---------------------------------------------------------
# Header
# ---------------------------------------------------------

header_frame = tk.Frame(
    root,
    bg=COLOR_PRIMARY,
    height=90
)
header_frame.pack(fill="x")
header_frame.pack_propagate(False)

header_content = tk.Frame(
    header_frame,
    bg=COLOR_PRIMARY
)
header_content.pack(
    fill="both",
    expand=True,
    padx=28
)

tk.Label(
    header_content,
    text="TraceFix AI",
    font=("Segoe UI", 24, "bold"),
    bg=COLOR_PRIMARY,
    fg="white"
).pack(
    anchor="w",
    pady=(14, 0)
)

tk.Label(
    header_content,
    text="AI Production Investigation and Recovery Copilot",
    font=("Segoe UI", 11),
    bg=COLOR_PRIMARY,
    fg="#DCEBFA"
).pack(anchor="w")


# ---------------------------------------------------------
# Main content
# ---------------------------------------------------------

main_content = tk.Frame(
    root,
    bg=COLOR_BACKGROUND
)
main_content.pack(
    fill="both",
    expand=True,
    padx=20,
    pady=18
)

main_content.grid_columnconfigure(0, weight=4)
main_content.grid_columnconfigure(1, weight=6)
main_content.grid_rowconfigure(0, weight=1)


# ---------------------------------------------------------
# Left input card
# ---------------------------------------------------------

input_card = tk.Frame(
    main_content,
    bg=COLOR_CARD,
    highlightbackground=COLOR_BORDER,
    highlightthickness=1
)
input_card.grid(
    row=0,
    column=0,
    sticky="nsew",
    padx=(0, 10)
)

tk.Label(
    input_card,
    text="Incident Input",
    font=("Segoe UI", 15, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20,
    pady=(18, 4)
)

tk.Label(
    input_card,
    text="Provide the production context and sanitized log evidence.",
    font=("Segoe UI", 9),
    bg=COLOR_CARD,
    fg=COLOR_MUTED
).pack(
    anchor="w",
    padx=20,
    pady=(0, 15)
)

tk.Label(
    input_card,
    text="Application",
    font=("Segoe UI", 10, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20
)

app_combo = ttk.Combobox(
    input_card,
    values=["CashLoanEliotFoboExtract"],
    state="readonly"
)
app_combo.pack(
    fill="x",
    padx=20,
    pady=(5, 12)
)
app_combo.current(0)

tk.Label(
    input_card,
    text="Environment",
    font=("Segoe UI", 10, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20
)

env_combo = ttk.Combobox(
    input_card,
    values=["DEV", "UAT", "PROD"],
    state="readonly"
)
env_combo.pack(
    fill="x",
    padx=20,
    pady=(5, 12)
)
env_combo.current(1)

tk.Label(
    input_card,
    text="Incident Details",
    font=("Segoe UI", 10, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20
)

incident_text = tk.Text(
    input_card,
    height=3,
    wrap="word",
    font=("Segoe UI", 10),
    relief="solid",
    borderwidth=1,
    padx=8,
    pady=8
)
incident_text.pack(
    fill="x",
    padx=20,
    pady=(5, 12)
)

tk.Label(
    input_card,
    text="Production Log",
    font=("Segoe UI", 10, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20
)

log_text = tk.Text(
    input_card,
    height=8,
    wrap="word",
    font=("Consolas", 9),
    relief="solid",
    borderwidth=1,
    padx=8,
    pady=8
)
log_text.pack(
    fill="both",
    expand=True,
    padx=20,
    pady=(5, 5)
)


# ---------------------------------------------------------
# File buttons
# ---------------------------------------------------------

file_actions_frame = tk.Frame(
    input_card,
    bg=COLOR_CARD
)
file_actions_frame.pack(
    fill="x",
    padx=20
)

upload_button = tk.Button(
    file_actions_frame,
    text="Upload Log",
    command=upload_log_file,
    bg="#E8F1FB",
    fg=COLOR_PRIMARY_DARK,
    activebackground="#D8E9F8",
    font=("Segoe UI", 9, "bold"),
    relief="flat",
    padx=14,
    pady=7,
    cursor="hand2"
)
upload_button.pack(side="left")

clear_button = tk.Button(
    file_actions_frame,
    text="Clear",
    command=clear_form,
    bg="#F2F4F7",
    fg=COLOR_TEXT,
    activebackground="#E4E7EC",
    font=("Segoe UI", 9, "bold"),
    relief="flat",
    padx=14,
    pady=7,
    cursor="hand2"
)
clear_button.pack(
    side="left",
    padx=(8, 0)
)

selected_file_label = tk.Label(
    input_card,
    text="No log file selected",
    font=("Segoe UI", 8),
    bg=COLOR_CARD,
    fg=COLOR_MUTED,
    anchor="w"
)
selected_file_label.pack(
    fill="x",
    padx=20,
    pady=(4, 5)
)


# ---------------------------------------------------------
# Sanitization warning
# ---------------------------------------------------------

warning_label = tk.Label(
    input_card,
    text=(
        "Sanitization required: Remove passwords, tokens, "
        "personal information, and account data."
    ),
    font=("Segoe UI", 8, "bold"),
    bg=COLOR_DANGER_BACKGROUND,
    fg=COLOR_DANGER,
    justify="left",
    wraplength=420,
    padx=8,
    pady=6
)

warning_label.pack(
    fill="x",
    padx=20,
    pady=(0, 8)
)

# ---------------------------------------------------------
# Analyze button and progress bar
# ---------------------------------------------------------

analyze_button = tk.Button(
    input_card,
    text="Analyze Incident",
    command=analyze_incident,
    bg=COLOR_PRIMARY,
    fg="white",
    activebackground=COLOR_PRIMARY_DARK,
    activeforeground="white",
    font=("Segoe UI", 11, "bold"),
    relief="flat",
    padx=20,
    pady=10,
    cursor="hand2"
)
analyze_button.pack(
    fill="x",
    padx=20
)

progress_bar = ttk.Progressbar(
    input_card,
    mode="indeterminate"
)
progress_bar.pack(
    fill="x",
    padx=20,
    pady=(6, 10)
)


# ---------------------------------------------------------
# Right results card
# ---------------------------------------------------------

result_card = tk.Frame(
    main_content,
    bg=COLOR_CARD,
    highlightbackground=COLOR_BORDER,
    highlightthickness=1
)
result_card.grid(
    row=0,
    column=1,
    sticky="nsew",
    padx=(10, 0)
)

tk.Label(
    result_card,
    text="Investigation Result",
    font=("Segoe UI", 15, "bold"),
    bg=COLOR_CARD,
    fg=COLOR_TEXT
).pack(
    anchor="w",
    padx=20,
    pady=(18, 4)
)

classification_value = tk.Label(
    result_card,
    text="Not analyzed",
    font=("Segoe UI", 11),
    bg=COLOR_CARD,
    fg=COLOR_MUTED,
    anchor="w",
    justify="left",
    wraplength=650
)
classification_value.pack(
    fill="x",
    padx=20,
    pady=(0, 14)
)


# ---------------------------------------------------------
# Result summary cards
# ---------------------------------------------------------

summary_frame = tk.Frame(
    result_card,
    bg=COLOR_CARD
)
summary_frame.pack(
    fill="x",
    padx=20,
    pady=(0, 14)
)

for column in range(3):
    summary_frame.grid_columnconfigure(column, weight=1)

priority_card = tk.Frame(
    summary_frame,
    bg="#EFF8FF",
    padx=12,
    pady=10
)
priority_card.grid(
    row=0,
    column=0,
    sticky="ew",
    padx=(0, 6)
)

tk.Label(
    priority_card,
    text="Priority",
    font=("Segoe UI", 8),
    bg="#EFF8FF",
    fg=COLOR_MUTED
).pack()

priority_value = tk.Label(
    priority_card,
    text="--",
    font=("Segoe UI", 16, "bold"),
    bg="#EFF8FF",
    fg=COLOR_PRIMARY
)
priority_value.pack()

severity_card = tk.Frame(
    summary_frame,
    bg=COLOR_DANGER_BACKGROUND,
    padx=12,
    pady=10
)
severity_card.grid(
    row=0,
    column=1,
    sticky="ew",
    padx=6
)

tk.Label(
    severity_card,
    text="Severity",
    font=("Segoe UI", 8),
    bg=COLOR_DANGER_BACKGROUND,
    fg=COLOR_MUTED
).pack()

severity_value = tk.Label(
    severity_card,
    text="--",
    font=("Segoe UI", 16, "bold"),
    bg=COLOR_DANGER_BACKGROUND,
    fg=COLOR_DANGER
)
severity_value.pack()

confidence_card = tk.Frame(
    summary_frame,
    bg=COLOR_SUCCESS_BACKGROUND,
    padx=12,
    pady=10
)
confidence_card.grid(
    row=0,
    column=2,
    sticky="ew",
    padx=(6, 0)
)

tk.Label(
    confidence_card,
    text="Confidence",
    font=("Segoe UI", 8),
    bg=COLOR_SUCCESS_BACKGROUND,
    fg=COLOR_MUTED
).pack()

confidence_value = tk.Label(
    confidence_card,
    text="--",
    font=("Segoe UI", 16, "bold"),
    bg=COLOR_SUCCESS_BACKGROUND,
    fg=COLOR_SUCCESS
)
confidence_value.pack()


# ---------------------------------------------------------
# Result tabs
# ---------------------------------------------------------

result_notebook = ttk.Notebook(result_card)
result_notebook.pack(
    fill="both",
    expand=True,
    padx=20,
    pady=(0, 16)
)

overview_tab = tk.Frame(
    result_notebook,
    bg=COLOR_CARD
)

evidence_tab = tk.Frame(
    result_notebook,
    bg=COLOR_CARD
)

actions_tab = tk.Frame(
    result_notebook,
    bg=COLOR_CARD
)

result_notebook.add(
    overview_tab,
    text="Overview"
)

result_notebook.add(
    evidence_tab,
    text="Evidence"
)

result_notebook.add(
    actions_tab,
    text="Actions & Experts"
)


def create_result_text(parent):
    result_container = tk.Frame(
        parent,
        bg=COLOR_CARD
    )
    result_container.pack(
        fill="both",
        expand=True
    )

    scrollbar = tk.Scrollbar(result_container)
    scrollbar.pack(
        side="right",
        fill="y"
    )

    text_widget = tk.Text(
        result_container,
        wrap="word",
        font=("Segoe UI", 10),
        bg=COLOR_CARD,
        fg=COLOR_TEXT,
        relief="flat",
        padx=14,
        pady=14,
        state="disabled",
        yscrollcommand=scrollbar.set
    )
    text_widget.pack(
        side="left",
        fill="both",
        expand=True
    )

    scrollbar.config(command=text_widget.yview)

    return text_widget


overview_text = create_result_text(overview_tab)
evidence_text = create_result_text(evidence_tab)
actions_text = create_result_text(actions_tab)


# ---------------------------------------------------------
# Status bar
# ---------------------------------------------------------

status_frame = tk.Frame(
    root,
    bg="#EAECF0",
    height=30
)
status_frame.pack(
    fill="x",
    side="bottom"
)

status_label = tk.Label(
    status_frame,
    text="Ready for incident analysis.",
    font=("Segoe UI", 9),
    bg="#EAECF0",
    fg=COLOR_MUTED
)
status_label.pack(
    anchor="w",
    padx=20,
    pady=6
)


# ---------------------------------------------------------
# Initial state and application start
# ---------------------------------------------------------

clear_results()

root.mainloop()