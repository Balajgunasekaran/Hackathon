from services.analyzer import analyze_log

sample_log = """
Database connection failed while retrieving trades.
DbException occurred during execution.
database connection attempt timed out.
"""

result = analyze_log(sample_log)

rule = result["rule"]

print("\nTRACEFIX AI INVESTIGATION REPORT")
print("=" * 40)

print("Scenario:", rule["scenario"])
print("Severity:", rule["severity"])
print("Confidence:", rule["confidence"])

print("\nMatched Patterns:")

for pattern in result["matched_patterns"]:
    print("-", pattern)

print("\nProbable Root Cause:")
print(rule["probableRootCause"])

print("\nRecovery Action:")
print(rule["recoveryAction"])

print("\nClassification:")
print(rule["scenario"])

priority_mapping = {
    "Critical": "P1",
    "High": "P2",
    "Medium": "P3"
}

priority = priority_mapping.get(rule["severity"], "P3")

print("\nPriority:")
print(priority)

print("\nInvestigation Steps:")

for step in rule["suggestedActions"]:
    print("-", step)

# Recommended Experts section goes HERE

expert_mapping = {
    "Trade Retrieval": [
        "Database Support Team",
        "Trade Services Team",
        "Infrastructure Support Team"
    ],
    "SFTP Delivery": [
        "Middleware Team",
        "Network Team",
        "SFTP Support Team"
    ],
    "Email Report Delivery": [
        "Messaging Team",
        "Application Support Team"
    ],
    "CSV Line Creation": [
        "Development Team",
        "Application Support Team"
    ],
    "Filter Initialization": [
        "Application Support Team",
        "Configuration Management Team"
    ]
}

experts = expert_mapping.get(
    rule["stage"],
    ["Application Support Team"]
)

print("\nRecommended Experts:")

for expert in experts:
    print("-", expert)