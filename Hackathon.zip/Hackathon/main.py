print("Starting TraceFix AI...")

from ui.main_window import *

print("TraceFix AI window closed.")